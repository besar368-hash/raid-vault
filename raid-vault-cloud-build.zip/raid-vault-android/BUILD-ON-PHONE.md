# Build RAID VAULT APK using only your Android phone

This project includes a GitHub Actions workflow that builds a debug APK in the cloud. You do not need Android Studio or a PC.

## Steps
1. On your phone, open https://github.com and sign in or create an account.
2. Create a **new private repository** named `raid-vault`.
3. Use the GitHub website's **Add file → Upload files** option and upload the contents of this project folder (including the hidden `.github/workflows/android-apk.yml` folder). If your mobile browser hides dot-folders, switch the browser to Desktop site or upload the ZIP and extract it using GitHub's web editor; the workflow file must be at `.github/workflows/android-apk.yml`.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build RAID VAULT APK**, then **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish successfully. Open the completed run, scroll to **Artifacts**, and download `raid-vault-debug-apk`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser or file manager.

## Important
- The APK produced by this workflow is a **debug build**, not a Play Store release. It is installable for personal testing.
- This source has not yet been independently built or security-audited. Test with dummy credentials first; do not put valuable RAID passwords in it until backup/restore and security testing are complete.
- The encrypted backup/export and restore workflow is not implemented in this starter yet.
- Keep the GitHub repository private. Never upload real account credentials, master passwords, keystore files, or backups to GitHub.
