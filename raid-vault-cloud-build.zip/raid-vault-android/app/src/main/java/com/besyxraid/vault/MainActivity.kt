package com.besyxraid.vault

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executor

private val Blood = Color(0xFFB71C1C)
private val Ink = Color(0xFF101010)
private val Panel = Color(0xFF1B1B1B)
private val Gold = Color(0xFFE0B04B)
private val BuiltIn = listOf("#ID", "Email", "Password", "Email password", "Plarium ID", "2FA / Recovery", "Price", "Status", "Account power", "Champions", "Mythicals", "Legendaries", "Relics", "Notes")

data class RaidAccount(val id: String, val fields: Map<String, String>, val status: String)

class MainActivity : ComponentActivity() {
    private lateinit var crypto: VaultCrypto
    private var vaultKey: ByteArray? = null
    private val executor: Executor by lazy { ContextCompat.getMainExecutor(this) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); crypto = VaultCrypto(this); setContent { VaultApp() } }

    private fun promptBiometric(onKey: (ByteArray) -> Unit, onError: (String) -> Unit) {
        try {
            val cipher = crypto.biometricDecryptCipher()
            val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    try { onKey(crypto.readBiometricBlob(result.cryptoObject!!.cipher!!)) } catch (e: Exception) { onError("Biometric key unavailable. Unlock with your master password.") }
                }
                override fun onAuthenticationError(code: Int, message: CharSequence) { onError(message.toString()) }
            })
            prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock RAID VAULT").setSubtitle("Authenticate to access your encrypted accounts").setNegativeButtonText("Use master password").build(), BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) { onError("Fingerprint unlock is unavailable. Use your master password.") }
    }

    private fun enrollBiometric(vaultKey: ByteArray, onDone: (String) -> Unit) {
        try {
            val cipher = crypto.biometricEncryptCipher()
            val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    try { crypto.saveBiometricBlob(result.cryptoObject!!.cipher!!, vaultKey); onDone("Fingerprint unlock enabled.") }
                    catch (e: Exception) { onDone("Could not enable fingerprint unlock.") }
                }
                override fun onAuthenticationError(code: Int, message: CharSequence) { onDone(message.toString()) }
            })
            prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Enable fingerprint unlock").setSubtitle("Protect access to your RAID VAULT key").setNegativeButtonText("Cancel").build(), BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) { onDone("Set up a strong fingerprint or biometric lock on your phone first.") }
    }

    @Composable private fun VaultApp() {
        var unlocked by remember { mutableStateOf(false) }
        var setup by remember { mutableStateOf(!crypto.exists()) }
        var key by remember { mutableStateOf<ByteArray?>(null) }
        var accounts by remember { mutableStateOf(listOf<RaidAccount>()) }
        var enabledFields by remember { mutableStateOf(listOf("Email", "Password", "Price", "Status")) }
        var message by remember { mutableStateOf("") }
        var master by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        var showFields by remember { mutableStateOf(false) }
        var editing by remember { mutableStateOf<RaidAccount?>(null) }
        var showEditor by remember { mutableStateOf(false) }
        var search by remember { mutableStateOf("") }
        var selectedStatus by remember { mutableStateOf("All") }

        fun encode(): ByteArray {
            val root = JSONObject(); root.put("enabledFields", JSONArray(enabledFields))
            val arr = JSONArray(); accounts.forEach { a -> val o=JSONObject();o.put("id",a.id);o.put("status",a.status);val f=JSONObject();a.fields.forEach{(k,v)->f.put(k,v)};o.put("fields",f);arr.put(o) };root.put("accounts",arr)
            return root.toString().toByteArray(Charsets.UTF_8)
        }
        fun decode(bytes: ByteArray) {
            val root=JSONObject(String(bytes,Charsets.UTF_8)); val f=root.optJSONArray("enabledFields")
            enabledFields=if(f!=null) List(f.length()){f.getString(it)} else listOf("Email","Password","Price","Status")
            val arr=root.optJSONArray("accounts")?:JSONArray();accounts=List(arr.length()){i->val o=arr.getJSONObject(i);val obj=o.getJSONObject("fields");val map=mutableMapOf<String,String>();obj.keys().forEach{map[it]=obj.getString(it)};RaidAccount(o.getString("id"),map,o.optString("status","Available"))}
        }
        fun persist(k: ByteArray) { crypto.save(encode(),k) }
        fun unlockWithPassword() {
            try {
                if(master.length<10){message="Use at least 10 characters for your master password.";return}
                val salt=crypto.salt() ?: crypto.newSalt().also{crypto.setSalt(it)}
                val derived=crypto.derive(master.toCharArray(),salt)
                if(setup){ key=derived;persist(derived);setup=false;unlocked=true;message="Vault created." }
                else { decode(crypto.load(derived));key=derived;unlocked=true;message="" }
                master=""
            } catch(e:Exception){message="Could not unlock. Check your master password."}
        }
        MaterialTheme(colorScheme=darkColorScheme(primary=Blood,secondary=Gold,background=Ink,surface=Panel)) {
            Surface(Modifier.fillMaxSize(),color=Ink) {
                if(!unlocked) {
                    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                        Text("RAID VAULT",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Black,color=Gold)
                        Text(if(setup)"Create your private vault" else "Your accounts are encrypted",color=Color.LightGray)
                        Spacer(Modifier.height(28.dp))
                        OutlinedTextField(master,{master=it},label={Text("Master password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
                        if(setup){Spacer(Modifier.height(8.dp));OutlinedTextField(confirm,{confirm=it},label={Text("Confirm master password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())}
                        Spacer(Modifier.height(12.dp));Button(onClick={if(setup&&master!=confirm)message="Passwords do not match." else unlockWithPassword()},modifier=Modifier.fillMaxWidth()) { Text(if(setup)"Create vault" else "Unlock vault") }
                        if(!setup&&crypto.hasBiometricKey()) { TextButton(onClick={promptBiometric({k->try{decode(crypto.load(k));key=k;unlocked=true}catch(e:Exception){message="Biometric unlock failed. Use your master password."}},{message=it})}){Icon(Icons.Default.Lock,null);Text(" Unlock with fingerprint")} }
                        Text(message,color=Color(0xFFFF7777));Text("Your vault is stored locally on this device.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("RAID VAULT",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Black,color=Gold);Text("Private account inventory",color=Color.LightGray)};TextButton(onClick={key?.let{k->enrollBiometric(k){message=it}}}){Text("Fingerprint")};TextButton(onClick={unlocked=false;key=null}){Icon(Icons.Default.Lock,null);Text("Lock")} }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { StatCard("${accounts.size}","Accounts",Modifier.weight(1f));StatCard("${accounts.count{it.status=="Available"}}","Available",Modifier.weight(1f)) }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("Search accounts")})
                        Row(verticalAlignment=Alignment.CenterVertically){var expanded by remember{mutableStateOf(false)};Box{TextButton(onClick={expanded=true}){Text("Status: $selectedStatus")};DropdownMenu(expanded,{expanded=false}){listOf("All","Available","Reserved","Sold","Personal").forEach{DropdownMenuItem(text={Text(it)},onClick={selectedStatus=it;expanded=false})}}};Spacer(Modifier.weight(1f));TextButton(onClick={showFields=true}){Text("⚙ Fields")};Button(onClick={editing=null;showEditor=true}){Icon(Icons.Default.Add,null);Text(" Add")}}
                        }
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),modifier=Modifier.weight(1f)) {
                            val shown=accounts.filter{(selectedStatus=="All"||it.status==selectedStatus)&&it.fields.values.any{v->v.contains(search,true)}.let{match->search.isBlank()||match}}
                            items(shown,key={it.id}) { account -> Card(colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Row(verticalAlignment=Alignment.CenterVertically){Text("#${account.fields["#ID"]?.ifBlank{account.id}?:account.id}",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(account.status,color=Gold)};account.fields.filterKeys{it!="Password"&&it!="Email password"}.forEach{(k,v)->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(k,color=Color.LightGray);Text(v,color=Color.White)}};Row{TextButton(onClick={editing=account;showEditor=true}){Icon(Icons.Default.Edit,null);Text("Edit")};TextButton(onClick={accounts=accounts.filterNot{it.id==account.id};key?.let{persist(it)}}){Icon(Icons.Default.Delete,null);Text("Delete")}} } } }
                        }
                        Text(message,color=Color(0xFFFF7777))
                    }
                    if(showFields) AlertDialog(onDismissRequest={showFields=false},title={Text("Choose account fields")},text={Column(Modifier.heightIn(max=420.dp)){BuiltIn.forEach{f->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=f in enabledFields,onCheckedChange={enabledFields=if(it)enabledFields+f else enabledFields-f});Text(f)}}}},confirmButton={TextButton(onClick={key?.let{persist(it)};showFields=false}){Text("Done")}})
                    if(showEditor) AccountDialog(enabledFields,editing,onDismiss={showEditor=false},onSave={fields,status->val item=editing?.copy(fields=fields,status=status)?:RaidAccount(java.util.UUID.randomUUID().toString(),fields,status);accounts=if(editing==null)accounts+item else accounts.map{if(it.id==item.id)item else it};key?.let{persist(it)};showEditor=false})
                }
            }
        }
    }
}

@Composable private fun StatCard(value:String,label:String,modifier:Modifier=Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel)){Column(Modifier.padding(14.dp)){Text(value,style=MaterialTheme.typography.headlineMedium,color=Gold,fontWeight=FontWeight.Bold);Text(label,color=Color.LightGray)}}}

@Composable private fun AccountDialog(fields:List<String>,existing:RaidAccount?,onDismiss:()->Unit,onSave:(Map<String,String>,String)->Unit){
    val values= remember(existing){mutableStateMapOf<String,String>().apply{existing?.fields?.let{putAll(it)}}};var status by remember(existing){mutableStateOf(existing?.status?:"Available")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Add account" else "Edit account")},text={Column(Modifier.heightIn(max=500.dp).fillMaxWidth().padding(top=4.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){fields.filter{it!="Status"}.forEach{f->OutlinedTextField(value=values[f]?:"",onValueChange={values[f]=it},label={Text(f)},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=if(f.lowercase().contains("password"))PasswordVisualTransformation()else androidx.compose.ui.text.input.VisualTransformation.None)};var expanded by remember{mutableStateOf(false)};Box{TextButton(onClick={expanded=true}){Text("Status: $status")};DropdownMenu(expanded,{expanded=false}){listOf("Available","Reserved","Sold","Personal").forEach{DropdownMenuItem(text={Text(it)},onClick={status=it;expanded=false})}}}}},confirmButton={TextButton(onClick={onSave(values.toMap(),status)}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
