package com.besyxraid.vault

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** AES-256-GCM vault encryption. The password-derived key is never persisted in plaintext. */
class VaultCrypto(private val context: Context) {
    private val file = File(context.filesDir, "vault.enc")
    private val prefs = context.getSharedPreferences("vault_meta", Context.MODE_PRIVATE)
    private val random = SecureRandom()

    fun exists() = file.exists()
    fun hasBiometricKey() = prefs.contains("bio_iv") && prefs.contains("bio_blob")

    fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, 310_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    fun newSalt(): ByteArray = ByteArray(16).also(random::nextBytes)

    fun encrypt(data: ByteArray, key: ByteArray): ByteArray {
        val iv = ByteArray(12).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(data)
    }

    fun decrypt(blob: ByteArray, key: ByteArray): ByteArray {
        require(blob.size > 12) { "Invalid encrypted vault" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
        return cipher.doFinal(blob.copyOfRange(12, blob.size))
    }

    fun save(data: ByteArray, key: ByteArray) { file.writeBytes(encrypt(data, key)) }
    fun load(key: ByteArray): ByteArray = decrypt(file.readBytes(), key)
    fun salt(): ByteArray? = prefs.getString("salt", null)?.let { Base64.decode(it, Base64.NO_WRAP) }
    fun setSalt(salt: ByteArray) { prefs.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP)).apply() }

    private fun biometricKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("raid_vault_biometric", null) as? SecretKey)?.let { return it }
        val gen = javax.crypto.KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder("raid_vault_biometric", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(true)
            .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
            .setInvalidatedByBiometricEnrollment(true).build())
        return gen.generateKey()
    }

    /** Call from BiometricPrompt CryptoObject. */
    fun biometricEncryptCipher(): Cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, biometricKey()) }
    fun biometricDecryptCipher(): Cipher {
        val key = biometricKey()
        val iv = Base64.decode(prefs.getString("bio_iv", ""), Base64.NO_WRAP)
        return Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv)) }
    }
    fun saveBiometricBlob(cipher: Cipher, vaultKey: ByteArray) {
        val blob = cipher.doFinal(vaultKey)
        prefs.edit().putString("bio_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("bio_blob", Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
    }
    fun readBiometricBlob(cipher: Cipher): ByteArray = cipher.doFinal(Base64.decode(prefs.getString("bio_blob", ""), Base64.NO_WRAP))
    fun clearBiometric() { prefs.edit().remove("bio_iv").remove("bio_blob").apply() }

    fun exportEncrypted(key: ByteArray): ByteArray {
        val payload = load(key)
        val backupSalt = newSalt()
        // Export uses a fresh password-derived key chosen by the user in the UI.
        return backupSalt + encrypt(payload, key)
    }
}
