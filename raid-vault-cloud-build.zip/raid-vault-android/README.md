# RAID VAULT — Android starter project

A native Android / Jetpack Compose starter for a private RAID: Shadow Legends account vault. Package: `com.besyxraid.vault`.

## Included in this starter
- Dark black / red interface with gold highlights
- Master-password setup and unlock
- Local vault file encrypted with AES-256-GCM
- Key derivation using PBKDF2-HMAC-SHA256 (310,000 iterations, random 16-byte salt)
- Android Keystore-backed biometric key wrapping (fingerprint/strong biometric enrollment and unlock)
- Add, edit, delete, search, status filter, and selectable built-in account fields
- Password fields masked in the account editor
- App backup disabled in Android manifest to avoid automatic cloud backup of app data
- GitHub Actions workflow to build a debug APK in the cloud

## Build an APK from your Android phone
Follow [BUILD-ON-PHONE.md](BUILD-ON-PHONE.md). No PC or Android Studio is required; a GitHub account and mobile browser are required.

## Important security and completeness notes
- This is source code, not a prebuilt APK. The cloud workflow must complete successfully before an APK is available.
- The encrypted vault is stored in the app's private internal storage. Keep your master password safe; there is no password-reset service.
- Biometric unlock is optional and can be enrolled after unlocking the vault. A biometric-enrollment change can invalidate the Keystore key; unlock with the master password and enroll again.
- Encrypted export/import and recovery workflows are not yet implemented. Do not treat this version as a complete backup solution until those flows are added and tested.
- This starter has not yet been built and device-tested. Use dummy credentials first and complete a security review before storing valuable credentials.
