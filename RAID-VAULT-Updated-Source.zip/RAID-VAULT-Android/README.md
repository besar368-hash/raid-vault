# RAID VAULT Android

Updated UI source for RAID VAULT.

## Changes in this revision
- Reworked input fields into individually spaced vertical blocks with explicit dimensions, padding, and rounded outlined backgrounds to prevent overlap.
- Improved scroll behavior and spacing on compact screens.
- Refined primary action styling with a red gradient and more consistent sizing.
- Added a custom RAID VAULT shield launcher icon (adaptive icon for Android 8.0+ and PNG fallbacks for older Android versions).

## Build
Open this folder in Android Studio and build the `app` debug APK (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).

The source project is provided; a rebuilt APK is not included because this build environment does not have the Android SDK/Gradle toolchain installed.
