# RAID VAULT — Personal Account Manager

A native Android app for privately organizing your own Raid: Shadow Legends accounts.

## Included in v1.0
- Local-only account storage (no registration, server, or cloud upload)
- Add, edit, view, search, and delete saved accounts
- Account type, level, power score, Mythicals, Legendaries, Void/Sacred shards, Gems, Silver, and notes
- Champion picker with a starter champion catalog
- Champion Library tab showing champions across saved accounts
- Dark charcoal and gold interface with a custom shield-style launcher icon
- Scrollable forms with vertically stacked fields to avoid overlapping controls

## Open in Android Studio
1. Extract this ZIP.
2. Open the `RaidVault` folder in Android Studio.
3. Allow Gradle sync to complete (Android Studio will download the required Gradle and Android dependencies).
4. Select an emulator or connect an Android phone with USB debugging enabled.
5. Press **Run**.

The project uses Kotlin, Jetpack Compose, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35. Java 17 is required.

## Data and privacy
Account data is saved in the app's private SharedPreferences storage on the device. Uninstalling the app or clearing its storage removes this data. This starter version does not yet include backup/export or image attachments.
