# RAID VAULT

A starter Android app for keeping RAID: Shadow Legends account details on one Android device.

## Build
Open this repository in Android Studio, or upload it to a GitHub repository and run **Actions → Build RAID VAULT APK**. The workflow uploads `RAID-VAULT-APK`.

## Included
- Dark black/red interface
- Master password setup and unlock (PBKDF2-HMAC-SHA256, 210,000 iterations)
- EncryptedSharedPreferences for local account data
- Optional biometric convenience unlock when supported
- Account name, email/login, password, price, status, #ID, notes and custom fields
- Add, edit, delete and search accounts

## Security notes
- This is a starter build, not a professionally audited password manager.
- Biometric unlock is a convenience gate; the master password remains the recovery method.
- No cloud sync or backup/export is included in this starter.
- Do not store valuable credentials until you have tested the app and reviewed its security. Keep a separate secure backup of credentials.
- AndroidX Security Crypto is deprecated upstream; replace it with a maintained encryption/storage implementation before production use.
