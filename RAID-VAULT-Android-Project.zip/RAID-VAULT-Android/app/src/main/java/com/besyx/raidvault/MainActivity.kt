package com.besyx.raidvault

import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

 data class VaultAccount(
    var name: String = "", var email: String = "", var password: String = "",
    var price: String = "", var status: String = "Available", var id: String = "",
    var notes: String = "", var customFields: String = ""
)

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private val gson = Gson()
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private val accounts = mutableListOf<VaultAccount>()
    private val bg = Color.rgb(9, 10, 13)
    private val panel = Color.rgb(22, 24, 30)
    private val panel2 = Color.rgb(30, 32, 39)
    private val red = Color.rgb(190, 27, 48)
    private val gold = Color.rgb(221, 174, 83)
    private val white = Color.rgb(245, 245, 247)
    private val muted = Color.rgb(155, 159, 170)
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        try {
            val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            prefs = EncryptedSharedPreferences.create(this, "raid_vault_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
            showGate()
        } catch (e: Exception) { showFatal("Secure storage could not be initialized: ${e.message}") }
    }

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 210000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return android.util.Base64.encodeToString(bytes, 2)
    }
    private fun biometricAvailable() = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
    private fun biometricUnlock() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true; loadAccounts(); showVault() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast(errString.toString()) }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock RAID VAULT").setSubtitle("Authenticate to open your local vault").setNegativeButtonText("Cancel").build())
    }
    private fun loadAccounts() {
        val type = object : TypeToken<MutableList<VaultAccount>>() {}.type
        val loaded: MutableList<VaultAccount> = gson.fromJson(prefs.getString("accounts", "[]") ?: "[]", type) ?: mutableListOf()
        accounts.clear(); accounts.addAll(loaded)
    }
    private fun saveAccounts() { prefs.edit().putString("accounts", gson.toJson(accounts)).apply() }

    private fun showGate() {
        val hasPin = prefs.getString("master_hash", null) != null
        screenBase()
        spacer(42)
        brandMark()
        heading(if (hasPin) "WELCOME BACK" else "YOUR PRIVATE VAULT")
        paragraph(if (hasPin) "Enter your master password to unlock your accounts." else "Create a master password to protect your RAID account inventory.")
        val pass = field("MASTER PASSWORD", "Enter master password", secret = true)
        val confirm = if (!hasPin) field("CONFIRM PASSWORD", "Repeat master password", secret = true) else null
        primaryButton(if (hasPin) "UNLOCK VAULT" else "CREATE SECURE VAULT") {
            val p = pass.text.toString()
            if (p.length < 10) { toast("Use at least 10 characters."); return@primaryButton }
            if (!hasPin) {
                if (p != confirm?.text.toString()) { toast("Passwords do not match."); return@primaryButton }
                val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                prefs.edit().putString("salt", android.util.Base64.encodeToString(salt, 2)).putString("master_hash", hash(p, salt)).apply()
                unlocked = true; loadAccounts(); showVault()
            } else {
                val salt = android.util.Base64.decode(prefs.getString("salt", ""), 2)
                if (hash(p, salt) == prefs.getString("master_hash", "")) { unlocked = true; loadAccounts(); showVault() }
                else toast("Incorrect master password.")
            }
        }
        if (hasPin && biometricAvailable()) secondaryButton("UNLOCK WITH BIOMETRICS") { biometricUnlock() }
        spacer(24)
        paragraph("ENCRYPTED ON THIS DEVICE  •  YOUR DATA STAYS LOCAL")
    }

    private fun showVault() {
        screenBase()
        val top = horizontal()
        val brand = vertical(); brand.addView(label("RAID", 13, gold, true)); brand.addView(label("VAULT", 27, white, true))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        smallButton("LOCK") { unlocked = false; showGate() }
        root.addView(top)
        paragraph("PRIVATE ACCOUNT INVENTORY")
        val stats = horizontal()
        statCard("TOTAL ACCOUNTS", accounts.size.toString(), stats)
        statCard("AVAILABLE", accounts.count { it.status == "Available" }.toString(), stats)
        root.addView(stats)
        primaryButton("＋   ADD NEW ACCOUNT") { showEditor(null) }
        val search = field("", "Search by name, email or ID")
        val list = vertical(); root.addView(list); list.tag = "account_list"
        search.addTextChangedListener(SimpleWatcher { renderList(it, list) })
        renderList("", list)
        spacer(24)
        paragraph("RAID VAULT  •  LOCAL ENCRYPTED STORAGE")
    }

    private fun statCard(caption: String, value: String, parent: LinearLayout) {
        val card = vertical().apply { background = rounded(panel, 14); setPadding(dp(14), dp(14), dp(14), dp(14)) }
        card.addView(label(caption, 10, muted, true)); card.addView(label(value, 25, gold, true))
        val lp = LinearLayout.LayoutParams(0, dp(82), 1f); lp.marginEnd = dp(8); parent.addView(card, lp)
    }

    private fun renderList(query: String, target: LinearLayout) {
        target.removeAllViews()
        val filtered = accounts.filter { listOf(it.name, it.email, it.id, it.status, it.notes).any { s -> s.contains(query, true) } }
        if (filtered.isEmpty()) {
            val empty = vertical().apply { gravity = Gravity.CENTER; background = rounded(panel, 16); setPadding(dp(20), dp(28), dp(20), dp(28)) }
            empty.addView(label(if (query.isBlank()) "YOUR VAULT IS EMPTY" else "NO MATCHES FOUND", 15, white, true))
            empty.addView(paragraphView(if (query.isBlank()) "Add your first RAID account to get started." else "Try another name, email or account ID."))
            target.addView(empty); return
        }
        filtered.forEach { account ->
            val card = vertical().apply { background = rounded(panel, 16); setPadding(dp(16), dp(14), dp(16), dp(14)) }
            val row = horizontal()
            row.addView(label(account.name.ifBlank { "UNTITLED ACCOUNT" }, 16, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            val statusColor = when (account.status) { "Available" -> Color.rgb(82, 190, 125); "Sold" -> gold; else -> muted }
            row.addView(pill(account.status, statusColor))
            card.addView(row)
            val info = listOfNotNull(account.price.takeIf { it.isNotBlank() }?.let { "${it}" }, account.id.takeIf { it.isNotBlank() }?.let { "ID $it" }).joinToString("   •   ")
            if (info.isNotBlank()) card.addView(label(info, 12, gold))
            if (account.email.isNotBlank()) card.addView(label(account.email, 12, muted))
            if (account.notes.isNotBlank()) card.addView(label(account.notes, 12, muted).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            val actions = horizontal(); actions.gravity = Gravity.END
            actions.addView(outlineButton("EDIT") { showEditor(account) })
            actions.addView(outlineButton("DELETE") {
                android.app.AlertDialog.Builder(this).setMessage("Delete this account?").setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ -> accounts.remove(account); saveAccounts(); renderList(query, target) }.show()
            })
            card.addView(actions)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); target.addView(card, lp)
        }
    }

    private fun showEditor(existing: VaultAccount?) {
        screenBase()
        val top = horizontal()
        top.addView(label("RAID VAULT", 13, gold, true), LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(smallButton("BACK") { showVault() })
        root.addView(top)
        heading(if (existing == null) "ADD ACCOUNT" else "EDIT ACCOUNT")
        paragraph("Account details are saved securely on this device. Fill in only what you need.")

        val name = field("ACCOUNT NAME", "e.g. Main account", initial = existing?.name)
        val email = field("EMAIL / LOGIN", "Account email or username", initial = existing?.email)
        val password = field("PASSWORD", "Account password", secret = true, initial = existing?.password)
        val price = field("PRICE", "e.g. 250 USD", initial = existing?.price)
        val id = field("ACCOUNT ID", "Game account ID", initial = existing?.id)

        sectionLabel("ACCOUNT STATUS")
        val status = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Available", "Reserved", "Sold", "Archived"))
            setSelection(listOf("Available", "Reserved", "Sold", "Archived").indexOf(existing?.status).takeIf { it >= 0 } ?: 0)
            background = rounded(panel2, 10)
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(16) })

        val notes = field("NOTES / CHAMPIONS / DETAILS", "Add champions, power, Hydra damage, relics…", initial = existing?.notes, multiline = true)
        val custom = field("CUSTOM FIELDS", "One per line: Label: Value", initial = existing?.customFields, multiline = true)
        spacer(4)
        primaryButton("SAVE ACCOUNT") {
            if (name.text.isBlank() && email.text.isBlank() && id.text.isBlank()) { toast("Enter an account name, email or ID."); return@primaryButton }
            val a = existing ?: VaultAccount()
            a.name = name.text.toString().trim(); a.email = email.text.toString().trim(); a.password = password.text.toString()
            a.price = price.text.toString().trim(); a.id = id.text.toString().trim(); a.status = status.selectedItem.toString()
            a.notes = notes.text.toString().trim(); a.customFields = custom.text.toString().trim()
            if (existing == null) accounts.add(a)
            saveAccounts(); showVault()
        }
        secondaryButton("CANCEL") { showVault() }
        spacer(18)
    }

    // All content is placed in one padded, scrollable vertical column. Fields are separate
    // labelled blocks with fixed minimum heights and margins to prevent overlap on small screens.
    private fun screenBase() {
        root = vertical().apply { setPadding(dp(20), dp(22), dp(20), dp(28)); background = android.graphics.drawable.ColorDrawable(bg) }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setPadding(0, 0, 0, dp(12)); addView(root, ScrollView.LayoutParams(-1, -2)) }
        setContentView(scroll)
    }
    private fun brandMark() {
        val mark = vertical().apply { gravity = Gravity.CENTER; background = rounded(panel, 22); setPadding(dp(22), dp(24), dp(22), dp(24)) }
        mark.addView(label("RV", 42, gold, true)); mark.addView(label("RAID VAULT", 13, white, true))
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(26); root.addView(mark, lp)
    }
    private fun heading(s: String) { val v = label(s, 24, white, true); val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(12); lp.bottomMargin = dp(4); root.addView(v, lp) }
    private fun paragraph(s: String) { root.addView(paragraphView(s)) }
    private fun paragraphView(s: String) = label(s, 13, muted).apply { setLineSpacing(dp(3).toFloat(), 1f); val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(16); layoutParams = lp }
    private fun sectionLabel(s: String) { val v = label(s, 11, gold, true); val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8); lp.bottomMargin = dp(7); root.addView(v, lp) }
    private fun field(caption: String, hint: String, secret: Boolean = false, initial: String? = null, multiline: Boolean = false): EditText {
        val block = vertical()
        if (caption.isNotBlank()) block.addView(label(caption, 10, gold, true).apply { letterSpacing = 0.08f })
        val input = EditText(this).apply {
            this.hint = hint; setText(initial ?: ""); textSize = 14f; setTextColor(white); setHintTextColor(Color.rgb(112, 116, 127))
            background = rounded(panel2, 10); setPadding(dp(14), dp(12), dp(14), dp(12))
            isSingleLine = !multiline
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else if (!multiline && caption.contains("PRICE", true)) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            if (multiline) { minLines = 3; maxLines = 6; gravity = Gravity.TOP; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; imeOptions = EditorInfo.IME_FLAG_NO_ENTER_ACTION }
        }
        block.addView(input, LinearLayout.LayoutParams(-1, if (multiline) dp(112) else dp(52)).apply { topMargin = dp(7) })
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(15); root.addView(block, lp)
        return input
    }
    private fun primaryButton(text: String, fn: () -> Unit): Button {
        val b = Button(this).apply { this.text = text; setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; isAllCaps = false; background = rounded(red, 12); setOnClickListener { fn() }; minHeight = dp(52); stateListAnimator = null }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8); bottomMargin = dp(10) }); return b
    }
    private fun secondaryButton(text: String, fn: () -> Unit): Button {
        val b = Button(this).apply { this.text = text; setTextColor(gold); textSize = 12f; isAllCaps = false; background = rounded(panel2, 12); setOnClickListener { fn() }; minHeight = dp(48); stateListAnimator = null }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(5); bottomMargin = dp(8) }); return b
    }
    private fun smallButton(text: String, fn: () -> Unit): Button = Button(this).apply { this.text = text; textSize = 10f; isAllCaps = false; setTextColor(gold); background = rounded(panel2, 9); setOnClickListener { fn() }; minHeight = dp(40); stateListAnimator = null }
    private fun outlineButton(text: String, fn: () -> Unit): Button = Button(this).apply { this.text = text; textSize = 10f; isAllCaps = false; setTextColor(gold); background = rounded(panel2, 8); setOnClickListener { fn() }; minHeight = dp(38); stateListAnimator = null; val lp = LinearLayout.LayoutParams(dp(86), dp(38)); lp.marginStart = dp(8); layoutParams = lp }
    private fun pill(text: String, color: Int) = TextView(this).apply { this.text = text.uppercase(); textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setTextColor(color); background = rounded(panel2, 30); setPadding(dp(9), dp(6), dp(9), dp(6)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun vertical() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun spacer(height: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun showFatal(s: String) { screenBase(); brandMark(); heading("RAID VAULT"); paragraph(s) }
}

class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
