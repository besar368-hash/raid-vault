package com.besyx.raidvault

import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class VaultAccount(
    var name: String = "",
    var email: String = "",
    var password: String = "",
    var price: String = "",
    var status: String = "Available",
    var id: String = "",
    var notes: String = "",
    var customFields: String = ""
)

class MainActivity : AppCompatActivity() {
    private val gson = Gson()
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private val accounts = mutableListOf<VaultAccount>()
    private val bg = Color.rgb(10, 10, 12)
    private val panel = Color.rgb(25, 25, 29)
    private val red = Color.rgb(190, 24, 45)
    private val white = Color.WHITE
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            prefs = EncryptedSharedPreferences.create(
                this, "raid_vault_secure",
                key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            showGate()
        } catch (e: Exception) {
            showFatal("Secure storage could not be initialized: ${e.message}")
        }
    }

    private fun showGate() {
        val salt = prefs.getString("salt", null)
        val hasPin = prefs.getString("master_hash", null) != null
        screenBase()
        titleText("RAID VAULT")
        subtitle(if (hasPin) "Enter your master password" else "Create your master password")
        val pass = edit("Master password", true)
        val confirm = if (!hasPin) edit("Confirm master password", true) else null
        action(if (hasPin) "UNLOCK VAULT" else "CREATE VAULT") {
            val p = pass.text.toString()
            if (p.length < 10) { toast("Use at least 10 characters."); return@action }
            if (!hasPin) {
                if (p != confirm?.text.toString()) { toast("Passwords do not match."); return@action }
                val s = ByteArray(16).also { SecureRandom().nextBytes(it) }
                prefs.edit().putString("salt", android.util.Base64.encodeToString(s, 2))
                    .putString("master_hash", hash(p, s)).apply()
                unlocked = true
                loadAccounts()
                showVault()
            } else {
                val s = android.util.Base64.decode(salt, 2)
                if (hash(p, s) == prefs.getString("master_hash", "")) {
                    unlocked = true
                    loadAccounts()
                    showVault()
                } else toast("Incorrect master password.")
            }
        }
        if (hasPin && biometricAvailable()) {
            action("UNLOCK WITH BIOMETRICS") { biometricUnlock() }
        }
        subtitle("Your vault is stored locally on this device. Never share your master password.")
    }

    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 210000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return android.util.Base64.encodeToString(bytes, 2)
    }

    private fun biometricAvailable() =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS

    private fun biometricUnlock() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                // Biometric is a convenience gate on this device; master password remains the recovery method.
                unlocked = true
                loadAccounts()
                showVault()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast(errString.toString()) }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock RAID VAULT")
                .setSubtitle("Authenticate to open your local vault")
                .setNegativeButtonText("Cancel")
                .build()
        )
    }

    private fun loadAccounts() {
        val raw = prefs.getString("accounts", "[]") ?: "[]"
        val type = object : TypeToken<MutableList<VaultAccount>>() {}.type
        val loaded: MutableList<VaultAccount> = gson.fromJson(raw, type) ?: mutableListOf()
        accounts.clear(); accounts.addAll(loaded)
    }

    private fun saveAccounts() {
        prefs.edit().putString("accounts", gson.toJson(accounts)).apply()
    }

    private fun showVault() {
        screenBase()
        val header = row()
        val title = text("RAID VAULT", 25, red)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val lock = Button(this).apply { text = "LOCK"; setOnClickListener { unlocked = false; showGate() } }
        header.addView(lock)
        root.addView(header)
        subtitle("${accounts.size} saved accounts • Encrypted local storage")
        action("+ ADD ACCOUNT") { showEditor(null) }
        val search = edit("Search accounts…")
        search.addTextChangedListener(SimpleWatcher { renderList(it) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "account_list" }
        root.addView(list)
        renderList("", list)
    }

    private fun renderList(query: String, target: LinearLayout? = null) {
        val container = target ?: root.findViewWithTag("account_list") ?: return
        container.removeAllViews()
        accounts.filter { listOf(it.name,it.email,it.id,it.status).any { s -> s.contains(query, true) } }
            .forEachIndexed { _, a ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14)
                    setBackgroundColor(panel)
                }
                val heading = text(a.name.ifBlank { "Unnamed account" }, 18, white)
                card.addView(heading)
                card.addView(text("${a.status}  •  ${a.price.ifBlank { "No price" }}  •  #${a.id}", 13, Color.LTGRAY))
                card.addView(text(a.email, 13, Color.GRAY))
                val buttons = row()
                val edit = Button(this).apply { text = "EDIT"; setOnClickListener { showEditor(a) } }
                val del = Button(this).apply { text = "DELETE"; setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity).setMessage("Delete this account?")
                        .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                            accounts.remove(a); saveAccounts(); renderList(query, container)
                        }.show()
                } }
                buttons.addView(edit); buttons.addView(del); card.addView(buttons)
                val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, 12)
                container.addView(card, lp)
            }
        if (container.childCount == 0) container.addView(text("No accounts found.", 14, Color.GRAY))
    }

    private fun showEditor(existing: VaultAccount?) {
        screenBase()
        titleText(if (existing == null) "ADD ACCOUNT" else "EDIT ACCOUNT")
        subtitle("Only fill in the fields you need.")
        val name = edit("Account name", initial = existing?.name)
        val email = edit("Email / login", initial = existing?.email)
        val password = edit("Password", true, existing?.password)
        val price = edit("Price", initial = existing?.price)
        val id = edit("#ID", initial = existing?.id)
        val status = Spinner(this)
        val statuses = listOf("Available", "Reserved", "Sold", "Archived")
        status.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, statuses)
        status.setSelection(statuses.indexOf(existing?.status).takeIf { it >= 0 } ?: 0)
        root.addView(text("Status", 13, Color.LTGRAY)); root.addView(status)
        val notes = edit("Notes / champions / details", initial = existing?.notes, multiline = true)
        val custom = edit("Custom fields (one per line: Label: Value)", initial = existing?.customFields, multiline = true)
        action("SAVE ACCOUNT") {
            if (name.text.isBlank() && email.text.isBlank() && id.text.isBlank()) {
                toast("Enter an account name, email or #ID."); return@action
            }
            val a = existing ?: VaultAccount()
            a.name=name.text.toString(); a.email=email.text.toString(); a.password=password.text.toString()
            a.price=price.text.toString(); a.id=id.text.toString(); a.status=status.selectedItem.toString()
            a.notes=notes.text.toString(); a.customFields=custom.text.toString()
            if (existing == null) accounts.add(a)
            saveAccounts(); showVault()
        }
        action("CANCEL") { showVault() }
    }

    private fun screenBase() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 24); setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }
    private fun titleText(s: String) { root.addView(text(s, 27, red)) }
    private fun subtitle(s: String) { root.addView(text(s, 14, Color.LTGRAY).apply { setPadding(0, 8, 0, 18) }) }
    private fun text(s: String, size: Int, color: Int) = TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); setPadding(0, 5, 0, 5)
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun edit(hint: String, secret: Boolean = false, initial: String? = null, multiline: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint=hint; setText(initial ?: ""); setTextColor(white); setHintTextColor(Color.GRAY)
            setSingleLine(!multiline)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            if (multiline) { minLines=3; gravity=Gravity.TOP; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            setPadding(14, 10, 14, 10); setBackgroundColor(panel)
        }
        val lp = LinearLayout.LayoutParams(-1, if (multiline) 120 else 56); lp.setMargins(0, 6, 0, 8)
        root.addView(e, lp); return e
    }
    private fun action(label: String, fn: () -> Unit) {
        val b = Button(this).apply {
            text=label; setTextColor(white); setBackgroundColor(red); setOnClickListener { fn() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 8, 0, 8); root.addView(b, lp)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun showFatal(s: String) { screenBase(); titleText("RAID VAULT"); subtitle(s) }
}

class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
